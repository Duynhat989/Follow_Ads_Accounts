(function () {
	'use strict';

	console.log("Facebook Script Added OneWise");

})();
